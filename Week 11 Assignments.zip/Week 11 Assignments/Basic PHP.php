<?php
//checking variable is set or not
if(isset($_POST['calculate']))
{
//assigning forms name value to variable value
$name=$_POST['name'];
//assigning forms year value to variable year
$year=$_POST['year'];
//displaying name 
echo "<b>Name:<b>".$name."<br>";
//calculating age in years using date() function
$calculate=date("Y")-$year ;
//displaying age
echo "<b>Age:<b>".$calculate; 
}
?>
        <html>
 <body>
        <center>
 <h3>Age Calculator</h3>
        <table border="0" width="25%">
//defining form attribute
         <form action="" method="post">
//getting input from user using textbox
             <td bgcolor="#FFCC00 ">Your name</td>
            <td><input type="text" name="name" maxlength="20"></td>
        </tr>
            <td bgcolor="#FFCC00">Your Birth year (ex. 2000.)</td>
            <td><input type="text" name="year" maxlength="4"></td>
        </tr>
     <br>
        <td colspan="2"><br><center><input type="submit"name="calculate"value="calculate"></center></td>
 </form>
         </center>
 <body>
 </html>